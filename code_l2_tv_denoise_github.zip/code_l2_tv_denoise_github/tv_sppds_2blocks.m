function [u, gap, time] = tv_sppds_2blocks(f, maxits, maxtime, est, lambda,sig, eta, mode)
    % SP-PDS for L^2-TV denoising demonstration script
    % Xiaokai Chang (2024)
    % A separable preconditioned primal-dual splitting algorithm.
    % ----------------------------------------------
    %
    % mode: 0 - demo, 1 - est, 2 - iter, 3 - time   
    % mode (optional) - demonstration mode
    %      'demo' (default) - demonstrate the method
    %      'iter' - record primal-dual gap for a fixed number of iterations
    %      'time' - record primal-dual gap for a fixed time interval
    %      'tol'  - record iterations/time to reach a certain tolerance
    %      'all'  - perform all tests

    disp('**********************************************************')
    if eta==1
        disp('Separable preconditioned PDS algorithm')
    else
        disp('Separable preconditioned PDS algorithm (relaxed)')
    end
    disp('**********************************************************') 

    tstart = tic; %for comparison with time 
    gap = zeros(maxits,1);
    time = zeros(maxits,1);

    dxp = @(u)diffop(u,2,0);
    dxm = @(u)diffop(u,2,1);
    dyp = @(u)diffop(u,1,0);
    dym = @(u)diffop(u,1,1);
    
    [m,n] = size(f);
    
    u = zeros(m,n,2);
    y = f;
    v = zeros(m,n); 
    sqrt_sig = sqrt(sig);
    
    for k = 1:maxits          
        %% compute z
        z = (sqrt_sig * v - f)/(1 + sig);   %% 
        
        %% compute y and Kty
        %y1 =  dctsolve((sig*sqrt_sig) *(dxm(u(:,:,1))+dym(u(:,:,2))) + sqrt_sig*v - 2*sig*z, sig^2, 1);
        y1 = rbsmooth(y,(sig*sqrt_sig) *(dxm(u(:,:,1))+dym(u(:,:,2))) + sqrt_sig*v - 2*sig*z, sig^2, 1, 3);

        sKty(:,:,1) = sqrt_sig * dxp(y1);  %% sqrt_sig * Kx
        sKty(:,:,2) = sqrt_sig * dyp(y1);
        
        %% compute x
        x = reproject(sqrt_sig * (u + 2*sKty), lambda);
        
        %% updating u and v with  relaxed step
        if eta >1
            u = (1 - eta)*u + eta * (x/sqrt_sig - sKty);
            v = (1 - eta)*v + eta * (y1/sqrt_sig + sqrt_sig * z);
            %y = (1 - eta)*y + eta * y1;
            y = y1;
        else  %%eta ==1
             u = x/sqrt_sig - sKty;
             v = y1/sqrt_sig + sqrt_sig * z;
             y = y1;
        end

        
        %%%%%%%%%%%%%%% gap 
        % fro norm of y -f
        g1 = (norm(y1 - f,'fro'))^2/2;
        
        % TV norm
        g2 = lambda*sum(sum(sqrt(dxp(y1).^2 + dyp(y1).^2)));     
    
        % dual
        div_v0 = dxm(x(:,:,1)) + dym(x(:,:,2));
        g3 = (norm(div_v0, 'fro'))^2/2;
        
        % inner product
        g4 = sum(sum(f.*div_v0));
        
        %%%%%%%%%%%%%%%%% test modes
        gap(k) = (g1+g2+g3+g4)/(n*m);
        time(k) = toc(tstart);
        
        if (mode <= 1) && (gap(k) < est)
            fprintf('Iter    Time   gap \n');
            fprintf('%d    %9.1f      %9.1e \n', k, time(k), gap(k));
            break;
        end
        
%         if (mode == 0) && (mod(k, 10) == 0) 
%             %imagesc(y); colormap(gray(256));
%             fprintf('Iteration %d: The primal-dual gap is %e.\n', k, gap(k));
%             %drawnow;
%         end
        
        if (mode == 3) && (time(k) > maxtime)
            break;
        end
       %u = u1;v = v1; 
    end

    u = y;
    gap = gap(1:k);
    time = time(1:k);    
end
