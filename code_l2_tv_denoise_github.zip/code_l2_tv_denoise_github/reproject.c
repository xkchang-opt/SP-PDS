/*==========================================================
 * reproject.c - projection operator for scalar, vector,
 *               and symmetric matrix fields
 * 
 * The calling syntax is:
 * 
 *     out = reproject(in, lambda)
 *    
 *     in     - input data
 *     lambda - radius of the \infty-ball to project onto
 * 
 * Copyright 2015 Kristian Bredies (kristian.bredies@uni-graz.at) 
 * and Hongpeng Sun (hpsun@amss.ac.cn).
 * 
 * If you use parts of this code, please cite:
 * 
 *   Kristian Bredies and Hongpeng Sun. 
 *   Preconditioned Douglas-Rachford algorithms for TV and TGV 
 *   regularized variational imaging problems. 
 *   Journal of Mathematical Imaging and Vision, 
 *   52(3):317-344, 2015. 
 * 
 *
 * Based on the file:
 * arrayProduct.c - example in MATLAB External Interfaces
 * Copyright 2007-2008 The MathWorks, Inc.
 *
 *========================================================*/

#define _USE_MATH_DEFINES
#include <omp.h>
#include "mex.h"
#include <math.h>

/* The computational routines */
void reproject1(double *outMatrix, double *xMatrix, double lambda, 
	        int dimN, int dimM)
{
  int i, j, ind0;
  double x0;
  
#pragma omp parallel for private (i, ind0, x0)
  for(j=0; j<dimM; j++) {
    ind0 = j*dimN;
    for(i=0; i<dimN; i++, ind0++) {
      x0 = xMatrix[ind0];
      if (x0 > lambda) x0 = lambda;
      if (x0 < -lambda) x0 = -lambda;
      outMatrix[ind0] = x0;
    }
  }
}

void reproject2(double *outMatrix, double *xMatrix, double lambda, 
	        int dimN, int dimM)
{
  int i, j, ind0, ind1;
  double lambda_inv, x0, x1, absval;
  
  lambda_inv = 1.0/lambda;
#pragma omp parallel for private (i, ind0, ind1, x0, x1, absval)
  for(j=0; j<dimM; j++) {
    ind0 = j*dimN;
    ind1 = ind0 + dimN*dimM;
    for(i=0; i<dimN; i++, ind0++, ind1++) {
      x0 = xMatrix[ind0];
      x1 = xMatrix[ind1];
      /* absval = sqrt(x0*x0 + x1*x1)*lambda_inv; */
      absval = hypot(x0, x1)*lambda_inv;
      if (absval < 1.0) absval = 1.0;
      outMatrix[ind0] = x0/absval;
      outMatrix[ind1] = x1/absval;
    }
  }
}

void reproject3(double *outMatrix, double *xMatrix, double lambda, 
		int dimN, int dimM)
{
  int i, j, ind0, ind1, ind2;
  double lambda_inv, x0, x1, x2, absval;
  
  lambda_inv = 1.0/lambda;
#pragma omp parallel for private (i, ind0, ind1, ind2, x0, x1, x2, absval)
  for(j=0; j<dimM; j++) {
    ind0 = j*dimN;
    ind1 = ind0 + dimN*dimM;
    ind2 = ind1 + dimN*dimM;
    for(i=0; i<dimN; i++, ind0++, ind1++, ind2++) {
      x0 = xMatrix[ind0];
      x1 = xMatrix[ind1];
      x2 = xMatrix[ind2];
      /* absval = sqrt(x0*x0 + x1*x1)*lambda_inv; */
      absval = hypot(hypot(x0,x1), M_SQRT2*x2)*lambda_inv;
      if (absval < 1.0) absval = 1.0;
      outMatrix[ind0] = x0/absval;
      outMatrix[ind1] = x1/absval;
      outMatrix[ind2] = x2/absval;
    }
  }
}

/* The gateway function */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[])
{
  double *xMatrix;
  double *outMatrix;
  double lambda;
  int dims[3];
  
  int i;
  
  /* check for proper number of arguments */
  if(nrhs!=2) {
    mexErrMsgIdAndTxt("MyToolbox:arrayProduct:nrhs","Two inputs required.");
  }
  if(nlhs!=1) {
    mexErrMsgIdAndTxt("MyToolbox:arrayProduct:nlhs","One output required.");
  }

  /* make sure the input arguments are scalar */
  if( !mxIsDouble(prhs[1]) || 
      mxIsComplex(prhs[1]) ||
      mxGetNumberOfElements(prhs[1])!=1 ) {
    mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notScalar","Input lambda must be scalar.");
    }

  /* get values of the scalar inputs  */
  lambda = mxGetScalar(prhs[1]);
  
  /* create pointers to the real data in the input matrices  */
  xMatrix = mxGetPr(prhs[0]);
  
  /* check number of dimensions */
  if (mxGetNumberOfDimensions(prhs[0]) == 2) {
    /* the two-dimensional case */

    dims[0] = mxGetDimensions(prhs[0])[0];
    dims[1] = mxGetDimensions(prhs[0])[1];

    /* create the output matrix */
    plhs[0] = mxCreateNumericArray(2, dims, mxDOUBLE_CLASS, mxREAL);
  
    /* get a pointer to the real data in the output matrix */
    outMatrix = mxGetPr(plhs[0]);

    reproject1(outMatrix, xMatrix, lambda, dims[0], dims[1]);
    return;
  }

  if (mxGetNumberOfDimensions(prhs[0]) != 3)
    mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notScalar","Input x must be two- or three-dimensional.");
  if (mxGetDimensions(prhs[0])[2] > 3)
    mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notScalar","Input x must have size 1, 2 or 3 in dimension 3.");
    
  /* get dimensions of the input matrix */
  dims[0] = mxGetDimensions(prhs[0])[0];
  dims[1] = mxGetDimensions(prhs[0])[1];
  dims[2] = mxGetDimensions(prhs[0])[2];
  
  /* create the output matrix */
  plhs[0] = mxCreateNumericArray(3, dims, mxDOUBLE_CLASS, mxREAL);
  
  /* get a pointer to the real data in the output matrix */
  outMatrix = mxGetPr(plhs[0]);
  
  /* call the computational routine */
  if (dims[2] == 1)
    reproject1(outMatrix, xMatrix, lambda, dims[0], dims[1]);
  else if (dims[2] == 2) 
    reproject2(outMatrix, xMatrix, lambda, dims[0], dims[1]);
  else 
    reproject3(outMatrix, xMatrix, lambda, dims[0], dims[1]);
}
