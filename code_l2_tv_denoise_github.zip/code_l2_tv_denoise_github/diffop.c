/*==========================================================
 * diffop.c - finite difference operators for 2D matrices
 * 
 * The calling syntax is:
 * 
 *     out = diffop(in, dim, ad)
 *    
 *     in  - input data
 *     dim - differentiation axis (1 or 2)
 *     ad  - forward (0) or backward (1) differences
 * 
 * Copyright 2015 Kristian Bredies (kristian.bredies@uni-graz.at) 
 * and Hongpeng Sun (hpsun@amss.ac.cn).
 * 
 * If you use parts of this code, please cite:
 * 
 *   Kristian Bredies and Hongpeng Sun. 
 *   Preconditioned Douglas-Rachford algorithms for TV and TGV 
 *   regularized variational imaging problems. 
 *   Journal of Mathematical Imaging and Vision, 
 *   52(3):317-344, 2015. 
 * 
 *
 * Based on the file:
 * arrayProduct.c - example in MATLAB External Interfaces
 * Copyright 2007-2008 The MathWorks, Inc.
 *
 *========================================================*/

#include <string.h>
#include <omp.h>
#include "mex.h"

/* The computational routines */
void dxp(double *outMatrix, double *xMatrix, int dimN, int dimM)
{
  int i, j, dimN_, ind;

  dimN_ = dimN - 1;
#pragma omp parallel for private (i, ind)
  for(j=0; j<dimM; j++) {
    ind = j*dimN;
    for(i=0; i<dimN_; i++, ind++)
      outMatrix[ind] = xMatrix[ind+1] - xMatrix[ind];
    outMatrix[ind] = 0.0;
  }
}

void dxm(double *outMatrix, double *xMatrix, int dimN, int dimM)
{
  int i, j, dimN_, ind;

  dimN_ = dimN - 1;  
#pragma omp parallel for private (i, ind)
  for(j=0; j<dimM; j++) {
    ind = j*dimN;
    outMatrix[ind] = xMatrix[ind]; ind++;
    for(i=1; i<dimN_; i++, ind++)
      outMatrix[ind] = xMatrix[ind] - xMatrix[ind-1];
    outMatrix[ind] = -xMatrix[ind-1];
  }
}

void dyp(double *outMatrix, double *xMatrix, int dimN, int dimM)
{
  int i, j, dimM_, ind;
  
  dimM_ = dimM - 1;
#pragma omp parallel for private (i, ind)
  for(j=0; j<dimM_; j++) {
    ind = j*dimN;
    for(i=0; i<dimN; i++, ind++)
      outMatrix[ind] = xMatrix[ind+dimN] - xMatrix[ind];
  }
  ind = dimM_*dimN;
  for(i=0; i<dimN; i++, ind++)
    outMatrix[ind] = 0.0;
}

void dym(double *outMatrix, double *xMatrix, int dimN, int dimM)
{
  int i, j, dimM_, ind;
  
  dimM_ = dimM - 1;
  for(i=0; i<dimN; i++)
    outMatrix[i] = xMatrix[i];
#pragma omp parallel for private (i, ind)
  for(j=1; j<dimM_; j++) {
    ind = j*dimN;
    for(i=0; i<dimN; i++, ind++)
      outMatrix[ind] = xMatrix[ind] - xMatrix[ind-dimN];
  }
  ind = dimM_*dimN;
  for(i=0; i<dimN; i++, ind++)
    outMatrix[ind] = -xMatrix[ind-dimN];
}

/* The gateway function */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[])
{
  double *xMatrix;
  double *outMatrix;
  int dim, ad;
  int dimN, dimM;
  
  int i;
  
  /* check for proper number of arguments */
  if(nrhs!=3) {
    mexErrMsgIdAndTxt("MyToolbox:arrayProduct:nrhs","Three inputs required.");
  }
  if(nlhs!=1) {
    mexErrMsgIdAndTxt("MyToolbox:arrayProduct:nlhs","One output required.");
  }

  /* make sure the input arguments are scalar */
  for(i=1; i<=2; i++)
    if( !mxIsDouble(prhs[i]) || 
	mxIsComplex(prhs[i]) ||
	mxGetNumberOfElements(prhs[i])!=1 ) {
      mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notScalar","Input dim and ad must be scalar.");
    }
  
  /* check number of dimensions */
  if (mxGetNumberOfDimensions(prhs[0]) != 2)
    mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notScalar","Input x must be two-dimensional.");
  
  /* get values of the scalar inputs  */
  dim = (int)mxGetScalar(prhs[1]);
  ad = (bool)mxGetScalar(prhs[2]);
  
  /* check for feasible directions */
  if ((dim != 1) && (dim != 2))
    mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notScalar","Input dim must be equal to 1 or 2.");

  /* create pointers to the real data in the input matrices  */
  xMatrix = mxGetPr(prhs[0]);
  
  /* get dimensions of the input matrix */
  dimN = mxGetM(prhs[0]);
  dimM = mxGetN(prhs[0]);
  
  /* create the output matrix */
  plhs[0] = mxCreateDoubleMatrix(dimN,dimM,mxREAL);
  
  /* get a pointer to the real data in the output matrix */
  outMatrix = mxGetPr(plhs[0]);
  
  /* call the computational routine */
  if (!ad) {
    if (dim == 1) dxp(outMatrix, xMatrix, dimN, dimM);
    else dyp(outMatrix, xMatrix, dimN, dimM);
  } else {
    if (dim == 1) dxm(outMatrix, xMatrix, dimN, dimM);
    else dym(outMatrix, xMatrix, dimN, dimM);      
  }
}
