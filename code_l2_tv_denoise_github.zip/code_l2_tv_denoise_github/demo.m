 %%%%%%%%%
 %% show the results for TV-regularized variational imaging problems
 clear all
 clc;
 % compile mex files
%     mex diffop.c CFLAGS="\$CFLAGS -fopenmp" LDFLAGS="\$LDFLAGS -fopenmp"
%     mex reproject.c CFLAGS="\$CFLAGS -fopenmp" LDFLAGS="\$LDFLAGS -fopenmp"
%     mex rbsmooth.c CFLAGS="\$CFLAGS -fopenmp" LDFLAGS="\$LDFLAGS -fopenmp"
addpath('images'); 
u_orig = double(imread('butterfly.png'))/255;
%u_orig   =  double(rgb2gray(imread('lighthouse2.bmp')))/255;
%% degraded by a Gaussian noise with zero mean and standard deviation
mu = 0;
d = 0.05;
L = sqrt(8);
f = imnoise(u_orig, 'gaussian', mu, d);
%%   regularization parameter and step sizes
  if d <=0.05
      lambda = 0.3; %regularization parameter
      sig  = 40/L;     
  else
      lambda = 0.5; %regularization parameter
      sig  = 60/L;
  end

inner = 2;
mode = 0;
est = 1e-7;
maxits = 2000;
maxtime = 200; % 

eta = 1.8;  %%relax parameter
%% relaxed CP-PDA 
[u_cp, gap_cp, time_cp] = tv_vu(f, maxits, maxtime, est, lambda, eta, mode);

%% PDR: Preconditioned Douglas-Rachford splitting method.
[u_pdr, gap_pdr, time_pdr] = tv_pdr(f, maxits, maxtime, est, lambda, sig, inner, mode);

%% separate preconditioned PDS
eta = 1.8;  %%relax parameter
[u_pds_relax, gap_pds_relax, time_pds_relax] = tv_sppds_2blocks(f, maxits, maxtime, est, lambda, sig,eta, mode);
eta = 1;
[u_pds, gap_pds, time_pds] = tv_sppds_2blocks(f, maxits, maxtime, est, lambda, sig,eta, mode);


figure(2);
p1 = semilogy(time_cp, gap_cp,'g-.');
hold on;
%p2 = semilogy(time_pdr, gap_pdr,'b-');
p3 = semilogy(time_pds, gap_pds,'k--');
p4 = semilogy(time_pds_relax, gap_pds_relax,'r-');

xlabel({'Time(second)'},'Interpreter','latex','FontSize',14);
ylabel({'$G(x_n,y_n)/(N_xN_y)$'},'Interpreter','latex','FontSize',14);
legend([p1 p3 p4],{'CP-PDA relaxed','SP-PDS','SP-PDS relaxed'});
set(gca,'FontSize',14,'LineWidth',2);


figure(1); 
subplot(1,3,1);
imshow(u_orig,'border','tight'); colormap(gray(256));axis off; title('original');
subplot(1,3,2);
imshow(f,'border','tight'); colormap(gray(256));axis off; title('noisy');
subplot(1,3,3);
imshow(u_pds_relax,'border','tight'); colormap(gray(256)); axis off; title('TVdenoised');

       
