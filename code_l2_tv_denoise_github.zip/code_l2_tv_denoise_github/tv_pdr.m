function [u, gap, time] = tv_pdr(f, maxits, maxtime, est, lambda, sigma, inner, mode)
        % PDRQ for L^2-TV denoising demonstration script
    % Bredies K, Sun HP (2015)
    % Preconditioned Douglas-Rachford algorithms for TV- and TGV-regularized variational imaging problems.
    % Journal of Mathematical Imaging and Vision 52(3):317-344
    % ----------------------------------------------
    %
    % Usage: l2_tv_pdrq(mode) 
    % mode: 0 - demo, 1 - est, 2 - iter, 3 - time    
    % mode (optional) - demonstration mode
    %      'demo' (default) - demonstrate the method
    %      'iter' - record primal-dual gap for a fixed number of iterations
    %      'time' - record primal-dual gap for a fixed time interval
    %      'tol'  - record iterations/time to reach a certain tolerance
    %      'all'  - perform all tests
    %    
    % Copyright 2015 Kristian Bredies (kristian.bredies@uni-graz.at) 
    % and Hongpeng Sun (hpsun@amss.ac.cn).
    % 
    % If you use parts of this code, please cite:
    % 
    %   Kristian Bredies and Hongpeng Sun. 
    %   Preconditioned Douglas-Rachford algorithms for TV and TGV 
    %   regularized variational imaging problems. 
    %   Journal of Mathematical Imaging and Vision, 
    %   52(3):317-344, 2015.
    
    disp('**********************************************************')
    disp('Preconditioned Douglas-Rachford algorithms')
    disp('**********************************************************') 

    tstart = tic; %for comparison with time 
    gap = zeros(maxits,1);
    time = zeros(maxits,1);

    dxp = @(u)diffop(u,2,0);
    dxm = @(u)diffop(u,2,1);
    dyp = @(u)diffop(u,1,0);
    dym = @(u)diffop(u,1,1);

    [m,n] = size(f);
    u = f; %x
    Ku(:,:,1)  = dxp(u);   
    Ku(:,:,2)  = dyp(u);
    x = u;

    q = zeros(m,n,2); %\bar p in pdrq

    for k = 1:maxits
        %% update of b
        b = x  + sigma * (dxm(q(:,:,1)) + dym(q(:,:,2))); %% b = x + sigma K^* y
        
       %% compute u and Ku
        %u = dctsolve(b, sigma^2, 1); %% u = u + M^{-1}(b - Tu)
        u = rbsmooth(u, b, sigma^2, 1, inner);    %% compute u  =  u + M^{-1} (b - Tx)
        
        Ku(:,:,1)  = dxp(u);   
        Ku(:,:,2)  = dyp(u);
        
        y = q + sigma * Ku;
        x = x + (2*u-x + sigma*f)/(1+sigma) - u;
        %% update of p_test
        p_test = reproject(q + 2*sigma*Ku, lambda);

        q = q +  p_test - y;
        %%%%%%%%%%%%%%% gap 
   
        % fro norm of u -f
        g1 = (norm(u - f,'fro'))^2/2;
        % TV norm
        g2 = lambda*sum(sum(sqrt(dxp(u).^2 + dyp(u).^2)));     
    
        % dual
        div_p = dxm(p_test(:,:,1)) + dym(p_test(:,:,2));
        g3 = (norm(div_p, 'fro'))^2/2;
        % inner product
        g4 = sum(sum(f.*div_p));
        
        %%%%%%%%%%%%%%%%% test modes

        gap(k) = (g1+g2+g3+g4)/(n*m);
        time(k) = toc(tstart);
        
        if (mode <= 1) && (gap(k) < est)
            fprintf('Iter    Time   gap \n');
            fprintf('%d    %9.1f      %9.1e \n', k, time(k), gap(k));
            break;
        end
        
%         if (mode == 0) && (mod(k, 10) == 0) 
%             %imagesc(u); colormap(gray(256));
%             fprintf('Iteration %d: The primal-dual gap is %e.\n', k, gap(k));
%             %drawnow;
%         end
        
        if (mode == 3) && (time(k) > maxtime)
            break;
        end
    end
   
    gap = gap(1:k);
    time = time(1:k);    
end


