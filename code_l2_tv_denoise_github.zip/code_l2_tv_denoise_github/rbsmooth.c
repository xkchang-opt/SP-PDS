/*==========================================================
 * rbsmooth.c - symmetric red-black Gauss-Seidel iteration
 *              for the solution of the elliptic equation
 *
 *                 alpha*u - tau*Laplace u = b
 * 
 * The calling syntax is:
 * 
 *     xk = rbsmooth(x0, b, tau, alpha, iter)
 *    
 *     x0         - initial guess
 *     b          - right-hand side
 *     tau, alpha - parameters for the equation
 *     iter       - number of symmetric Gauss-Seidel steps
 * 
 * Copyright 2015 Kristian Bredies (kristian.bredies@uni-graz.at) 
 * and Hongpeng Sun (hpsun@amss.ac.cn).
 * 
 * If you use parts of this code, please cite:
 * 
 *   Kristian Bredies and Hongpeng Sun. 
 *   Preconditioned Douglas-Rachford algorithms for TV and TGV 
 *   regularized variational imaging problems. 
 *   Journal of Mathematical Imaging and Vision, 
 *   52(3):317-344, 2015. 
 * 
 *
 * Based on the file:
 * arrayProduct.c - example in MATLAB External Interfaces
 * Copyright 2007-2008 The MathWorks, Inc.
 *
 *========================================================*/

#include <string.h>
#include <omp.h>
#include "mex.h"

/* The computational routine */
void symmetricRedBlack(double *xMatrix, double *bMatrix, double tau, 
		       double alpha, int k, int dimN, int dimM)
{
  int iter, start, i, j, dif, ind;
  double coeff, tau_inv, tau_alpha;
  int dimN_, dimM_;

  dimN_ = dimN - 1;
  dimM_ = dimM - 1;

  tau_inv = 1.0/tau;
  tau_alpha = alpha/tau;

  /* outer iteration */
  for(iter=0; iter<=2*k; iter++) {
    /* even iteration -> red, odd iteration -> black */
#pragma omp parallel for private (start, i, coeff, dif, ind)
    for(j=0; j<dimM; j++) {
      /* alternate the rows */
      start = (iter + j) & 1;
      ind = j*dimN + start;
      for(i=start; i<dimN; i+=2, ind+=2) {
	/* right hand side */
	coeff = bMatrix[ind]*tau_inv;
	dif = 0;
	/* add the neighbors */
	if (i > 0) { coeff += xMatrix[ind-1]; dif++; }
	if (i < dimN_) { coeff += xMatrix[ind+1]; dif++; }
	if (j > 0) { coeff += xMatrix[ind-dimN]; dif++; }
	if (j < dimM_) { coeff += xMatrix[ind+dimN]; dif++; }	  
	/* update entry */
	xMatrix[ind] = coeff/(tau_alpha + dif);
      }
    }
  }
}

/* The gateway function */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[])
{
    double *xMatrix;
    double *bMatrix;
    double tau;
    double alpha;
    int k;
    double *outMatrix;
    int dimN, dimM;

    int i;

    /* check for proper number of arguments */
    if(nrhs!=5) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:nrhs","Five inputs required.");
    }
    if(nlhs!=1) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:nlhs","One output required.");
    }

    /* make sure the input arguments are scalar */
    for(i=2; i<=4; i++)
      if( !mxIsDouble(prhs[i]) || 
	  mxIsComplex(prhs[i]) ||
	  mxGetNumberOfElements(prhs[i])!=1 ) {
        mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notScalar","Input alpha and tau must be scalar.");
      }
    
    /* check number of dimensions */
    for(i=0; i<=1; i++)
      if (mxGetNumberOfDimensions(prhs[i]) != 2)
	mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notScalar","Input x and b must be two-dimensional.");

    /* check for same size */
    if ((mxGetN(prhs[0]) != mxGetN(prhs[1])) 
	|| (mxGetM(prhs[0]) != mxGetM(prhs[1])))
      mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notScalar","Input x and b must have the same size.");

    /* check for minimal size */
    if ((mxGetN(prhs[0]) <= 2) || (mxGetM(prhs[0]) <= 2))
      mexErrMsgIdAndTxt("MyToolbox:arrayProduct:notScalar","Input x and b must have minimum size of 3x3.");

    /* get values of the scalar inputs  */
    tau = mxGetScalar(prhs[2]);
    alpha = mxGetScalar(prhs[3]);
    k = (int)mxGetScalar(prhs[4]);

    /* create pointers to the real data in the input matrices  */
    xMatrix = mxGetPr(prhs[0]);
    bMatrix = mxGetPr(prhs[1]);

    /* get dimensions of the input matrix */
    dimN = mxGetM(prhs[0]);
    dimM = mxGetN(prhs[0]);

    /* create the output matrix */
    plhs[0] = mxCreateDoubleMatrix(dimN,dimM,mxREAL);

    /* get a pointer to the real data in the output matrix */
    outMatrix = mxGetPr(plhs[0]);
    /* copy data */
    memcpy(outMatrix, xMatrix, sizeof(double)*dimN*dimM);

    /* call the computational routine */
    symmetricRedBlack(outMatrix, bMatrix, tau, alpha, k, dimN, dimM);
}
