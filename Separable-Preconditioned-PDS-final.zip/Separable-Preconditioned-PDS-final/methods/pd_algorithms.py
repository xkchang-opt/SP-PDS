import numpy as np
import numpy.linalg as LA
from itertools import count
from time import time
import scipy.linalg as scp_LA

"""
The following methods are based on the Chambolle and Pock PDA.
"""
def pd_SP_PDA(J, prox_g, prox_f, K, x0, y0, sigma, tau, eta, inex, min_val, numb_iter=100, tol=1e-12):
    """
    The separable preconditioned primal-dual algorithm for the problem min_x max_y [<Kx,y> + g(x) - f*(y)] 
    J denotes some function which we compute in every iteration to
    study perfomance. It may be energy, primal-dual gap, etc.
    """
    z0 = K.dot(x0)
    m,n = K.shape
 
    I1 = np.eye(m)
    M = (sigma*tau) * np.dot(K, K.T) +  I1
    if inex == 1:  ##  M \succ I+\tsu\sigma np.dot(K, K.T)
        D0 = np.diag(1/np.sqrt(np.diag(M))) 
        M0 = np.tril(M,0)
        L = M0.dot(D0)
    else:       ##  M = I+\tsu\sigma np.dot(K, K.T)
        L = LA.cholesky(M)
            
    values = [J(x0, y0, min_val)]
    tt = [0]  
    iterates = [values, x0, z0, y0] + [tt]

    def T(values, x_old, z_old, y_old, tt):
        # compute z
        z = prox_f(z_old + y_old/sigma, 1/sigma) 
        #y1 = prox_f_conj(sigma*z_old + y_old, sigma)
        #z = z_old + 1/sigma * (y_old  - y1)
        
        # compute y
        h_hat = K.dot(x_old)-(2*z-z_old)
        h = scp_LA.solve_triangular(L, h_hat, lower=True)
        h = scp_LA.solve_triangular(L.T, h, lower=False)
        y = y_old + sigma*h

        # compute x
        x = prox_g(x_old - tau * K.T.dot(2*y - y_old), tau) 
        
        # relax step 
        if eta > 1:
            x = eta * x + (1-eta)* x_old
            y = eta * y + (1-eta)* y_old
            z = eta * z + (1-eta) * z_old

        values.append(J(x, y, min_val))
        tt.append(time() - begin)
        res = [values, x, z, y, tt]
        return res
        
    count_ = 0
    begin = time()
    err = 1
    while count_ < numb_iter and err > tol:
        iterates = T(*iterates)
        err = iterates[0][-1]
        count_ += 1
            
    end = time()
    print ("----- separable preconditioned PDS (3 blocks)-----")
    print ("Time execution:", round(end - begin,2))
    print("iteration:")
    print(len(iterates[-1])-1)
    print("error:")
    print(err)
    return [iterates[i] for i in [0, -1]]

def pd_PDR_3block(J, prox_g, prox_f, K, x0, y0, sigma, tau, eta, inex, min_val, numb_iter=100, tol=1e-12):
    """
    The preconditioned Douglas–Rachford (PDR) splitting method for the problem min_x max_y [<Kx,y> + g(x) - f*(y)] 
    This is a 3-block reformulation of PDR, written by Xiaokai Chang
    J denotes some function which we compute in every iteration to
    study perfomance. It may be energy, primal-dual gap, etc.
    """
    z0 = K.dot(x0)
    m,n = K.shape
 
    I1 = np.eye(m)
    M = (sigma*tau) * np.dot(K, K.T) +  I1
    if inex == 1:
        D0 = np.diag(1/np.sqrt(np.diag(M))) 
        M0 = np.tril(M,0)
        L = M0.dot(D0)
    else:
        L = LA.cholesky(M)
            
    values = [J(x0, y0, min_val)]
    tt = [0]  
   
    iterates = [values, x0, z0, y0] + [tt]
    def T(values, x_old, z_old, y_old, tt):
        # compute y
        h_hat = K.dot(x_old) - z_old
        h = scp_LA.solve_triangular(L, h_hat, lower=True)
        h = scp_LA.solve_triangular(L.T, h, lower=False)
        y = y_old + sigma*h

        # compute x
        x = prox_g(x_old - tau * K.T.dot(2*y - y_old), tau) 
        
        # compute z
        z = prox_f(z_old + (2*y - y_old)/sigma, 1/sigma) 
        #y1 = prox_f_conj(sigma*z_old + y_old, sigma)
        #z = z_old + 1/sigma * (y_old  - y1)
        if eta > 1:
            x = eta * x + (1-eta)* x_old
            y = eta * y + (1-eta)* y_old
            z = eta * z + (1-eta) * z_old
            
   

        values.append(J(x, y, min_val))
        tt.append(time() - begin)
        res = [values, x, z, y, tt]
        return res
        
    count_ = 0
    begin = time()
    err = 1
    while count_ < numb_iter and err > tol:
        iterates = T(*iterates)
        err = iterates[0][-1]
        count_ += 1
            
    end = time()
    print ("----- Preconditioned Douglas-Rachford (Bredies and Sun) (3 blocks)-----")
    print ("Time execution:", round(end - begin,2))
    print("iteration:")
    print(len(iterates[-1])-1)
    print("error:")
    print(err)
    return [iterates[i] for i in [0, -1]]


def pd_SP_PDA_2block(J, prox_g, prox_f, K, x0, y0, sigma, tau, eta, min_val, numb_iter=100, tol=1e-12):
    """
    The relaxed 2-block SP-PDS for the problem min_x max_y [<Kx,y> + g(x) - f*(y)] 
    J denotes some function which we compute in every iteration to
    study perfomance. It may be energy, primal-dual gap, etc.
    """
    z0 = K.dot(x0)
    sqrt_tau = np.sqrt(tau)
    sqrt_sigma = np.sqrt(sigma)
    
    u = 1/sqrt_tau *x0 + sqrt_tau * K.T.dot(y0)
    v = 1/sqrt_sigma *y0 + sqrt_sigma * z0

    m,n = K.shape
    I1 = np.eye(m)
    M = (sigma*tau) * np.dot(K, K.T) +  I1
    L = LA.cholesky(M)

    values = [J(x0, y0, min_val)]
    tt = [0]      
    iterates = [values, u, v] + [tt]

    def T(values, u, v, tt):
        # compute z
        z = prox_f(1/sqrt_sigma * v, 1/sigma) 
        #y1 = prox_f_conj(sqrt_sigma * v, sigma)
        #z = 1/sqrt_sigma * v- 1/sigma * y1
   
        # compute y
        h_hat = sqrt_tau * K.dot(u) + 1/sqrt_sigma * v - 2*z
        h = scp_LA.solve_triangular(L, h_hat, lower=True)
        y  = sigma * scp_LA.solve_triangular(L.T, h, lower=False)
        Kty = K.T.dot(y)
      
        # compute x
        x = prox_g(np.sqrt(tau) * u - 2*tau * Kty, tau) 
        if eta > 1:
            u = eta * (1/sqrt_tau * x + sqrt_tau * Kty) + (1-eta) * u
            v = eta * (1/sqrt_sigma * y + sqrt_sigma * z) + (1-eta) * v
        else:
            u = 1/sqrt_tau * x + sqrt_tau * Kty
            v = 1/sqrt_sigma * y + sqrt_sigma * z
        

        values.append(J(x, y, min_val))
        tt.append(time() - begin)
        res = [values, u,v, tt]
        return res
        
    count_ = 0
    begin = time()
    err = 1
    while count_ < numb_iter and err > tol:
        iterates = T(*iterates)
        err = iterates[0][-1]
        count_ += 1
            
    end = time()
    print ("----- separable preconditioned PDS (2 blocks)-----")
    print ("Time execution:", round(end - begin,2))
    print("iteration:")
    print(len(iterates[-1])-1)
    print("error:")
    print(err)
    return [iterates[i] for i in [0, -1]]


def pd_PDR(J, prox_g, prox_f_conj, K, x0, y0, sigma, tau, inex, min_val, numb_iter=100, tol=1e-12):
    """
    The Preconditioned Douglas-Rachford (Bredies and Sun) for the problem min_x max_y [<Kx,y> + g(x) - f*(y)] 
    J denotes some function which we compute in every iteration to
    study perfomance. It may be energy, primal-dual gap, etc.
    """
    bx0 = x0
    by0 = y0
    m,n = K.shape
 
    I1 = np.eye(n)
    M = (sigma*tau) * np.dot(K.T, K) +  I1
    if inex == 1:
        D0 = np.diag(1/np.sqrt(np.diag(M))) 
        M0 = np.tril(M,0)
        L = M0.dot(D0)
    else:
        L = LA.cholesky(M)
    
    values = [J(x0, y0, min_val)]
    tt = [0]  
    Tx = x0 + sigma**2 * K.T.dot(K.dot(x0))
    
    iterates = [values, x0, bx0, y0, by0] +[Tx] + [tt]

    def T(values, x, bx, y, by, Tx, tt):
        # compute b
        b = bx - sigma * K.T.dot(by)

        if inex == 1:
            h = scp_LA.solve_triangular(L, b - Tx, lower=True)
            h = scp_LA.solve_triangular(L.T, h, lower=False)
            x = x + h
            Kx = K.dot(x)
            Tx = x + sigma**2 * K.T.dot(Kx)   
        else:
            h = scp_LA.solve_triangular(L, b, lower=True)
            h = scp_LA.solve_triangular(L.T, h, lower=False)
            x = h
            Kx = K.dot(x)
            
        # compute y
        y = by + sigma * Kx
        
        x1 = prox_g(2*x - bx, sigma)
        y1 = prox_f_conj(2*y - by, sigma)
        
        # compute bar{x} and bar{y}
        bx = bx + x1 - x
        by = by + y1 - y

        values.append(J(x, y, min_val))
        tt.append(time() - begin)
        res = [values, x, bx, y, by, Tx, tt]
        return res
        
    count_ = 0
    begin = time()
    err = 1
    while count_ < numb_iter and err > tol:
        iterates = T(*iterates)
        err = iterates[0][-1]
        count_ += 1
            
    end = time()
    print ("----- Preconditioned Douglas-Rachford (Bredies and Sun) -----")
    print ("Time execution:", round(end - begin,2))
    print("iteration:")
    print(len(iterates[-1])-1)
    
    print("objective function value error:")
    print(err)
    return [iterates[i] for i in [0, -1]]


def pd(J, prox_g, prox_f_conj, K,  x0, y0, sigma, tau, min_val, numb_iter=100,tol = 1e-8):
    """
    Primal-dual algorithm of Pock and Chambolle for the problem min_x
    max_y [<Kx,y> + g(x) - f*(y)]
    J denotes some function which we compute in every iteration to
    study perfomance. It may be energy, primal-dual gap, etc.
    """
    begin = time()  # process_time()
    theta = 1.0
    x, y, z = x0, y0, x0
    values = [J(x0, y0, min_val)]
    time_list = [time() - begin]
    for i in range(numb_iter):
        x1 = prox_g(x - tau * K.T.dot(y), tau)
        z = x1 + theta * (x1 - x)
        y = prox_f_conj(y + sigma * K.dot(z), sigma)
        x = x1
        values.append(J(x, y, min_val))
        # time_list.append(process_time() - begin)
        time_list.append(time() - begin)
        err = values[-1]
        end = time()
        if err <= tol:
            print ("Iter:", i+1)
            print ("----- Chambolle-Pock PDA (fixed step sizes)-----")
            print ("Time execution:", round(end - begin,2))
            break
            
    if err > tol:
        print ("Chambolle-Pock PDA does not terminate after", round(end - begin,2), "seconds")
        print(err)
    return [values, x, y, time_list]

def pd_accelerated_primal(J, prox_g, prox_f_conj, K,  x0, y0, sigma, tau, gamma, numb_iter=100):
    """
    Accelerated primal-dual algorithm of Pock and Chambolle for problem
    min_x max_y [<Kx,y>  + g(x) - f*(y)], where g is gamma-strongly convex
    """
    begin = time()
    theta = 1.0
    x, y, z = x0, y0, x0
    values = [J(x0, y0)]
    time_list = [process_time() - begin]
    for i in range(numb_iter):
        y = prox_f_conj(y + sigma * K.dot(z), sigma)
        x1 = prox_g(x - tau * K.T.dot(y), tau)
        theta = 1. / np.sqrt(1 + gamma * tau)
        tau *= theta
        sigma *= 1. / theta
        z = x1 + theta * (x1 - x)
        x = x1
        values.append(J(x, y))
        time_list.append(time() - begin)
    end = time()
    print(
        "----- Accelerated primal-dual method (g(x) is strongly convex)-----")
    print("Time execution:", round(end - begin,2))
    return [time_list, values, x, y]


def pd_linesearch(J, prox_g, prox_f_conj, K,  x0, y1, tau, beta, min_val, numb_iter=100,tol=1e-8):
    """
    Primal-dual method with linesearch for problem min_x max_y [
    <Kx,y> + g(x) - f*(y)].  Corresponds to Alg.1 in the paper.
    beta denotes sigma/tau from a classical primal-dual algorithm.
    """
    begin = time()
    theta = 1
    values = [J(x0, y1, min_val)]
    time_list = [time() - begin]
    mu = 0.7
    delta = 0.99
    iterates = [time_list, values, x0, y1, theta, tau, K.dot(x0), 0]
    sqrt_b = np.sqrt(beta)

    # function T is an operator that makes one iteration of the algorithm:
    # (x1, y1) = T(x,y, history)

    def T(time_list, values, x_old, y, th_old, tau_old, Kx_old, l):
        x = prox_g(x_old - tau_old * K.T.dot(y), tau_old)
        Kx = K.dot(x)
        th = np.sqrt(1 + th_old)
        for j in count(0):
            tau = tau_old * th
            z = x + th * (x - x_old)
            Kz = Kx + th * (Kx - Kx_old)
            y1 = prox_f_conj(y + tau * beta * Kz, tau * beta)
            if sqrt_b * tau * LA.norm(K.T.dot(y1 - y)) <= delta * LA.norm(y1 - y):
                break
            else:
                th *= mu
                l +=1
        values.append(J(x, y1, min_val))
        time_list.append(time() - begin)
        res = [time_list, values, x,  y1, th, tau, Kx, l]
        return res

    for i in range(numb_iter):
        iterates = T(*iterates)
        err = iterates[1][-1]
        end = time()
        if err <= tol:
            print ("Iter:", i+1)
            
            print ("----- Primal-dual method with linesearch-----")
            print ("Time execution:", round(end - begin,2))
            break
            
    if err > tol:
        print ("Primal-dual method with linesearch does not terminate after", round(end - begin,2), "seconds")

    print ("Number of linesearch:", iterates[-1])
    return iterates[:4]


def pd_linesearch_acceler_primal(J, prox_g, prox_f_conj, K,  x0, y1, tau, beta, gamma, numb_iter=100):
    """
    Accelerated primal-dual algorithm with linesearch for problem
    min_x max_y [<Kx,y>  + g(x) - f*(y)],
    where g is gamma-strongly convex
    """
    begin = time()
    theta = 1.0
    values = [J(x0, y1)]
    time_list = [process_time() - begin]
    mu = 0.7
    delta = 1.0
    iterates = [time_list, values, x0, y1, theta, tau, beta, K.dot(x0), 0]

    def T(time_list, values, x_old, y, th_old, tau_old, beta_old, Kx_old, l):
        x = prox_g(x_old - tau_old * K.T.dot(y), tau_old)
        Kx = K.dot(x)
        beta = (1.0 + gamma * tau_old) * beta_old
        sqrt_b = np.sqrt(beta)
        tau = tau_old * np.sqrt(beta_old / beta * (1. + th_old))
        # Linesearch starts
        for j in count(0):
            th = tau / tau_old
            z = x + th * (x - x_old)
            Kz = Kx + th * (Kx - Kx_old)
            y1 = prox_f_conj(y + tau * beta * Kz, tau * beta)
            if sqrt_b * tau * LA.norm(K.T.dot(y1 - y)) <= delta * LA.norm(y1 - y):
                break
            else:
                tau *= mu
                l +=1

        values.append(J(x, y1))
        time_list.append(time() - begin)
        res = [values, time_list, x, y1, th, tau, beta, Kx, l]
        return res

    for i in range(numb_iter):
        iterates = T(*iterates)

    end = time()
    print(
        "----- Accelerated primal-dual method with linesearch (g is strongly convex) -----")
    print("Time execution:", round(end - begin,2))
    print ("Number of linesearch:", iterates[-1])
    return iterates[:4]


def pd_linesearch_acceler_dual(J, prox_g, prox_f_conj, K,  x0, y1, tau, beta, gamma, numb_iter=100):
    """
    Accelerated primal-dual algorithm with linesearch for problem
    min_x max_y [<Kx,y>  + g(x) - f*(y)],
    where f* is gamma-strongly convex
    """
    begin = time()
    theta = 1.0
    values = [J(x0, y1)]
    time_list = [process_time() - begin]
    mu = 0.7
    delta = 1.0
    iterates = [time_list, values, x0, y1, theta, tau, beta, K.dot(x0), 0]

    def T(time_list, values, x_old, y, th_old, tau_old, beta_old, Kx_old, l):
        x = prox_g(x_old - tau_old * K.T.dot(y), tau_old)
        Kx = K.dot(x)
        beta = beta_old / (1.0 + gamma * beta_old * tau_old)
        sqrt_b = np.sqrt(beta)
        tau = tau_old * np.sqrt(1. + th_old)
        # Linesearch starts
        for j in count(0):
            th = tau / tau_old
            sigma = beta * tau
            z = x + th * (x - x_old)
            Kz = Kx + th * (Kx - Kx_old)
            y1 = prox_f_conj(y + sigma * Kz, sigma)
            if sqrt_b * tau * LA.norm(K.T.dot(y1 - y)) <= delta * LA.norm(y1 - y):
                break
            else:
                tau *= mu
                l+=1
        values.append(J(x, y1))
        time_list.append(time() - begin)
        res = [time_list, values, x, y1, th, tau, beta, Kx, l]
        return res

    for i in range(numb_iter):
        iterates = T(*iterates)

    end = time()
    print(
        "----- Accelerated primal-dual method with linesearch (f^* is strongly convex) -----")
    print("Time execution:", round(end - begin,2))
    print ("Number of linesearch:", iterates[-1])
    return iterates[:4]


def pd_linesearch_dual_is_square_norm(J, prox_g, b, K,  x0, y1, tau, beta, min_val, numb_iter=100, tol=1e-8):
    """
    Primal-dual method with linesearch for min_x max_y [ <Kx,y> + g(x) - f*(y) ]
    for the case when f*(y) = 0.5||y-b||^2
    """
    begin = time()
    theta = 1
    values = [J(x0, y1, min_val)]
    time_list = [time() - begin]
    mu = 0.7
    delta = 0.99
    Kx0 = K.dot(x0)
    iterates = [time_list, values, x0, y1,
                theta, tau, Kx0, K.T.dot(Kx0), K.T.dot(y1), 0]
    sqrt_beta = np.sqrt(beta)
    KTb = K.T.dot(b)

    def T(time_list, values, x_old, y, th_old, tau_old, Kx_old, KTKx_old, KTy, l):
        # Note that KTy = K.T.dot(y)
        x = prox_g(x_old - tau_old * KTy, tau_old)
        Kx = K.dot(x)
        KTKx = K.T.dot(Kx)
        th = np.sqrt(1 + th_old)
        for j in count(0):
            tau = tau_old * th
            sigma = tau * beta
            z = x + th * (x - x_old)
            Kz = Kx + th * (Kx - Kx_old)
            y1 = (y + sigma * (Kz + b)) / (1. + sigma)
            KTKz = (1 + th) * KTKx - th * KTKx_old
            KTy1 = (KTy + sigma * (KTKz + KTb)) / (1. + sigma)
            if sqrt_beta * tau * LA.norm(KTy1 - KTy) <= delta * LA.norm(y1 - y):
                break
            else:
                th *= mu
                l+=1
        values.append(J(x, y1, min_val))
        time_list.append(time() - begin)
        res = [time_list, values, x, y1, th, tau, Kx, KTKx,  KTy1, l]
        return res

    for i in range(numb_iter):
        iterates = T(*iterates)
        err = iterates[1][-1]
        end = time()
        if err <= tol:
            print ("Iter:", i+1)
            
            print ("----- Primal-dual method with  linesearch. f^*(y)=0.5*||y-b||^2------")
            print ("Time execution:", round(end - begin,2))
            break
            
    if err > tol:
        print ("Primal-dual method with  linesearch. f^*(y)=0.5*||y-b||^2 does not terminate after", round(end - begin,2), "seconds")

    print ("Number of linesearch:", iterates[-1])
    return iterates[:4]


def pd_linesearch_dual_is_linear(J, prox_g, c, K,  x0, y1, tau, beta, numb_iter=100):
    """
    Primal-dual method with linesearch for min_x max_y [ <Kx,y> + g(x) - f*(y) ]
    for the case when f*(y) = (c,y)
    """
    begin = time()
    theta = 1
    values = [J(x0, y1)]
    time_list = [time() - begin]
    mu = 0.7
    delta = 0.99
    Kx0 = K.dot(x0)
    iterates = [time_list, values, x0, y1,
                theta, tau, Kx0, K.T.dot(Kx0), K.T.dot(y1),0]
    sqrt_beta = np.sqrt(beta)
    KTc = K.T.dot(c)

    def T(time_list, values, x_old, y, th_old, tau_old, Kx_old, KTKx_old, KTy, l):
        # Note that KTy = K.T.dot(y)
        x = prox_g(x_old - tau_old * KTy, tau_old)
        Kx = K.dot(x)
        KTKx = K.T.dot(Kx)
        th = np.sqrt(1 + th_old)
        for j in count(0):
            tau = tau_old * th
            sigma = tau * beta
            z = x + th * (x - x_old)
            Kz = Kx + th * (Kx - Kx_old)
            y1 = y + sigma * (Kz - c)
            KTKz = (1 + th) * KTKx - th * KTKx_old
            KTy1 = KTy + sigma * (KTKz - KTc)
            if sqrt_beta * tau * LA.norm(KTy1 - KTy) <= delta * LA.norm(y1 - y):
                break
            else:
                th *= mu
                l+=1
        values.append(J(x, y1))
        time_list.append(time() - begin)
        res = [time_list, values, x, y1, th, tau, Kx, KTKx,  KTy1, l]
        return res

    for i in range(numb_iter):
        iterates = T(*iterates)

    end = time()
    print("----- Primal-dual method with linesearch. f^*(y)=(c,y)----")
    print("Time execution:", round(end - begin,2))
    print ("Number of linesearch:", iterates[-1])
    return iterates[:4]


def pd_linesearch_general(J, prox_g, prox_f_conj, h, dh, K,  x0, y1, tau, beta, numb_iter=100):
    """
    Primal-dual method with  linesearch for problem min_x max_y [
    <Kx,y> + g(x) - f*(y)-h(y)].  Corresponds to Alg.4 in the paper.
    """
    begin = process_time()
    theta = 1
    values = [J(x0, y1)]
    time_list = [process_time() - begin]
    mu = 0.7
    delta = 0.99
    iterates = [time_list, values, x0, y1, theta, tau, K.dot(x0)]
    sqrt_b = np.sqrt(beta)

    # function T is an operator that makes one iteration of the algorithm:
    # (x1, y1) = T(x,y, history)

    def T(time_list, values, x_old, y, th_old, tau_old, Kx_old):
        x = prox_g(x_old - tau_old * K.T.dot(y), tau_old)
        Kx = K.dot(x)
        th = np.sqrt(1 + th_old)
        dhy = dh(y)
        hy = h(y)
        for j in count(0):
            tau = tau_old * th
            sigma = beta * tau
            z = x + th * (x - x_old)
            Kz = Kx + th * (Kx - Kx_old)
            y1 = prox_f_conj(y + sigma * (Kz - dhy), sigma)
            hy1 = h(y1)
            if sigma * tau * (LA.norm(K.T.dot(y1 - y)))**2 + 2 * sigma * (hy1 - hy - dhy.dot(y1 - y)) <= delta * np.dot(y1 - y, y1 - y):
                break
            else:
                th *= mu
        # print(j, tau)
        values.append(J(x, y1))
        time_list.append(process_time() - begin)
        res = [time_list, values, x,  y1, th, tau, Kx]
        return res

    for i in range(numb_iter):
        iterates = T(*iterates)

    end = process_time()
    print("----- General primal-dual method with linesearch-----")
    print("Time execution:", end - begin)
    return iterates[:4]


def pd_linesearch_general_particular(J, prox_g, c, H, b, gamma, K,  x0, y1, tau, beta, numb_iter=100):
    """
    Primal-dual method with linesearch for problem min_x max_y [
    <Kx,y> + g(x) - f^*(y) -h(y)].  where f*(y) = \lr{c,y}, h(y) =
    gamma/2 * ||Hy-b||^2
    """
    begin = time()
    theta = 1
    # x, y = x0, y1
    values = [J(x0, y1)]
    time_list = [time() - begin]
    mu = 0.7
    delta = 0.99
    Kx0 = K.dot(x0)
    KTc = K.T.dot(c)
    HTb = H.T.dot(b)
    iterates = [time_list, values, x0, y1, theta, tau, Kx0, K.T.dot(
        Kx0), K.T.dot(y1), H.dot(y1), H.dot(Kx0)]
    sqrt_b = np.sqrt(beta)

    # function T is an operator that makes one iteration of the algorithm:
    # (x1, y1) = T(x,y, history)

    def T(time_list, values, x_old, y, th_old, tau_old, Kx_old, KTKx_old, KTy, Hy, HKx_old):
        x = prox_g(x_old - tau_old * K.T.dot(y), tau_old)
        Kx = K.dot(x)
        KTKx = K.T.dot(Kx)
        HTHy = H.T.dot(Hy)
        HKx = H.dot(Kx)
        expr = gamma * (HTHy - HTb) - c
        H_expr = H.dot(expr)
        KT_expr = K.T.dot(expr)

        th = np.sqrt(1 + th_old)
        for j in count(0):
            tau = tau_old * th
            sigma = beta * tau
            z = x + th * (x - x_old)
            Kz = (1 + th) * Kx - th * Kx_old
            KTKz = (1 + th) * KTKx - th * KTKx_old
            HKz = (1 + th) * HKx - th * HKx_old
            t = Kz - expr
            Ht = HKz - H_expr
            KTt = KTKz - KT_expr
            # y1 = y + sigma * (Kz - gamma*(HTHy -HTb) -c)

            if sigma * tau * LA.norm(KTt)**2 + 2 * sigma * gamma * LA.norm(Ht)**2 <= delta * LA.norm(t)**2:
                y1 = y + sigma * t
                Hy1 = Hy + sigma * Ht
                KTy1 = KTy + sigma * KTt
                break
            else:
                th *= mu
        # print j, tau * sigma
        values.append(J(x, y1))
        time_list.append(time() - begin)
        res = [time_list, values, x,  y1, th, tau, Kx, KTKx, KTy1, Hy1, HKx]
        return res

    for i in range(numb_iter):
        iterates = T(*iterates)

    end = process_time()
    print("----- Primal-dual method with linesearch-----")
    print("Time execution:", end - begin)
    return iterates[:4]  # fixed this, previously was wrong


def pd_linesearch_acceler_dual_is_square_norm(J, prox_g, b, K,  x0, y1, tau, beta, gamma,  min_val,  numb_iter=100):
    """
    Accelerated primal-dual method with linesearch for min_x max_y [
    <Kx,y> + g(x) - f*(y) ] for the case when f*(y) = 0.5||y-b||^2
    """
    begin = time()
    theta = 1
    values = [J(x0, y1, min_val)]
    time_list = [time() - begin]
    mu = 0.7
    delta = 0.99
    Kx0 = K.dot(x0)
    iterates = [time_list, values, x0, y1,
                theta, tau, beta, Kx0, K.T.dot(Kx0), K.T.dot(y1), 0]
    KTb = K.T.dot(b)

    def T(time_list, values, x_old, y, th_old, tau_old, beta_old, Kx_old, KTKx_old, KTy, l):
        # Note that KTy = K.T.dot(y)
        x = prox_g(x_old - tau_old * KTy, tau_old)
        Kx = K.dot(x)
        KTKx = K.T.dot(Kx)
        beta = beta_old / (1.0 + gamma * beta_old * tau_old)
        sqrt_beta = np.sqrt(beta)
        tau = tau_old * np.sqrt(1. + th_old)
        # Linesearch starts
        for j in count(0):
            th = tau / tau_old
            sigma = beta * tau
            z = x + th * (x - x_old)
            Kz = Kx + th * (Kx - Kx_old)
            y1 = (y + sigma * (Kz + b)) / (1. + sigma)
            KTKz = (1 + th) * KTKx - th * KTKx_old
            KTy1 = (KTy + sigma * (KTKz + KTb)) / (1. + sigma)
            if sqrt_beta * tau * LA.norm(KTy1 - KTy) <= delta * LA.norm(y1 - y):
                break
            else:
                tau *= mu
                l+=1
        values.append(J(x, y1, min_val))
        time_list.append(time() - begin)
        res = [time_list, values, x, y1, th, tau, beta, Kx, KTKx, KTy1, l]
        return res

    for i in range(numb_iter):
        iterates = T(*iterates)

    end = time()
    print(
        "----- Accelerated primal-dual method with  linesearch for dual f^*(y)=0.5*||y-b||^2-----")
    print("Time execution:", round(end - begin,2))
    print ("Number of linesearch:", iterates[-1])
    return iterates[:4]
